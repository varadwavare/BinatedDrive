<!DOCTYPE html>
<html>
<head>
    <title>Create New Post</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }

        h1 {
            text-align: center;
        }

        form {
            max-width: 400px;
            margin: 0 auto;
        }

        label {
            font-weight: bold;
        }

        input[type="text"],
        textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        input[type="checkbox"] {
            margin-right: 5px;
        }

        input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <h1>Create New Post</h1>

    <?php
    // Handle form submission
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $postTitle = $_POST["post_title"];
        $postContent = $_POST["post_content"];
        $selectedTopics = isset($_POST["topics"]) ? $_POST["topics"] : [];

        // Process the form data or save it to a database
        // For this example, let's just display the submitted data
        echo "<h3>Submitted Post Data:</h3>";
        echo "<p>Title: $postTitle</p>";
        echo "<p>Content: $postContent</p>";
        echo "<p>Selected Topics: " . implode(", ", $selectedTopics) . "</p>";
    }
    ?>

    <form method="POST" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
        <h3>Post Details</h3>
        <label for="post_title">Title:</label>
        <input type="text" id="post_title" name="post_title" required><br><br>

        <label for="post_content">Content:</label>
        <textarea id="post_content" name="post_content" rows="4" required></textarea><br><br>

        <h3>Blog Topics</h3>
        <label for="topic1"><input type="checkbox" id="topic1" name="topics[]" value="Topic 1"> Topic 1</label><br>
        <label for="topic2"><input type="checkbox" id="topic2" name="topics[]" value="Topic 2"> Topic 2</label><br>
        <label for="topic3"><input type="checkbox" id="topic3" name="topics[]" value="Topic 3"> Topic 3</label><br><br>

        <input type="submit" value="Submit">
    </form>
</body>
</html>
